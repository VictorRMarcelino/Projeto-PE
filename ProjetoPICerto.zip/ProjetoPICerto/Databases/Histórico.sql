create database historico;

use historico;

CREATE TABLE `historico` (
  `Nome` varchar(40) NOT NULL,
  `Data`timestamp(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

Select * from historico.historico;